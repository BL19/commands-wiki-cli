go build -o build/cwc
cp build/cwc /usr/local/bin/cwc